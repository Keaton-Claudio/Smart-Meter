/*
The MIT License (MIT)

Copyright (c) 2025 Keaton Claudio

Modified to use with Custom Metering PCB

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files 
(the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, 
publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR 
ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH
 THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

/*
ATM90E32 Initialization portion taken from ATM90E32.cpp at https://github.com/CircuitSetup/ATM90E32/blob/master/ATM90E32.cpp
Post dated 2016 by whatnick,Ryzee and Arun and later modified by jdeglavina in 2020

Function names, register names, and some register write values later modified by KClaudio
Registers with changed values are indicated by a blank comment preceding it: /**/	//they are usually followed by how they were found/calculated

/***************************************************
Class:			TECH 4945 Fall 2025
Date Created:	2/13/2025
Name:			Keaton Claudio
Revision: 1

Description:
Set up communication between an Arduino & Custom Meter PCB, read values, and send out using an ESP.

Communication:
	Arduino Pin		EPS8266 Pin		Atmel Pin		Usage
		9				RX			   PB1			TX (unused)
		2				TX			   PD2			RX (INT0)

Input:
	Arduino Pin		ESP8266 Pin		Atmel Pin		Usage
		12				-			   PB4			MISO (Device to Master)		
		
Output:		
	Arduino Pin		ESP8266 Pin		Atmel Pin		Usage
		10				-			   PB2			Chip Select from Arduino
		11				-			   PB3			MOSI (Master to Device)
		13				-			   PB5			Clock Output To 7-Segment								
***************************************************/

#include <atmel_start.h>
#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include <string.h>
#include <avr/interrupt.h>
#include <stdlib.h>

#define BAUD 9600
#define STOP_BITS 1
#define SOFT_TX_BIT 0
#define SOFT_TX_DDR DDRB
#define SOFT_TX_PORT PORTB
#define SOFT_RX_BIT 2
#define SOFT_RX_DDR DDRD
#define SOFT_RX_PORT PIND
#define MICROSECONDS_OVERHEAD_ADJUST 0
#define MICROSECONDS_PER_BIT ((1000000ul / BAUD) - MICROSECONDS_OVERHEAD_ADJUST)

volatile uint8_t rx_char;
volatile uint8_t rx_flag=0;
volatile char x[500];
volatile int c=0;
uint8_t address;		//SPI 8 bit Register location
uint16_t data;			//SPI 16 bit Register value

/* Function Prototypes */
void serial_configure();
int usart_putchar (char);
void usart_putstr (char *);
void usart_response (bool print);
void setup_ATs();
void senddata(uint8_t address, uint16_t data);		//SPI Communication Functions
uint16_t requestdata(uint8_t address);				//SPI Request
int requestdata32b(uint8_t highaddress, uint8_t lowaddress); 
void atm90e32initialization();
void negativecheck(float *currentA, float *currentB, float *currentC, int *wattsA, int *wattsB, int *wattsC);

int main(void)
{
	int length;
	char string1[50];		//CIPSEND & length string buffer
	char string2[350];		//Serialized json string buffer
	
	/* Initialization */
	atmel_start_init();
	PRR = 0x01;										// Full Arduino Power minus ADC	
	DDRB &= ~(_BV(DDB4));							// Set DDB4 as input from SPI (MISO)					
	DDRB |= _BV(DDB2) | _BV(DDB3) | _BV(DDB5);		// Set DDB2,3,5 as output, (CS, MOSI, SCLK respectively)
	PORTB |= _BV(PORTB2);							// Set CS high initially (not enabled)
	SPCR = _BV(SPE) | _BV(MSTR) | _BV(CPOL) | _BV(CPHA) | _BV(SPR1) | _BV(SPR0);		// Enable SPI (makes PB5 output a clock) & Make the Arduino a Master	//SPI MODE 3 & 125kHz
    TCCR1A = 0;										// Timer1 Minimum Time Between Loops
    TCCR1B = _BV(CS12);								// Set prescaler to 256
	
	serial_configure();
	_delay_ms(100);
	//atm90e32initialization();
	_delay_ms(500);
	setup_ATs();
	_delay_ms(200);

	while (1)	// flow = read energy data registers, save to memory, format, send to esp, esp transmits serialized json string, wait x time, loop
	{
		if (TIFR1 & _BV(TOV1))	// Only run if 1s since last loop
		{
			TIFR1 = _BV(TOV1);  // Check if 1s since last main loop (overflow), clear the flag just before running main loop

			//Repeatedly fetch some values from the ATM90E32 (test vals)
			float voltage = 119, currentA = 15.2, currentB = 75.14, currentC = 162.53 , freq = 59.9, totalCurrent = 252.87 , totalWatts = 1150, wattsA = 380, wattsB = 360, wattsC = 410, powerfactortot = 0.966, temp = 27.5; 
			
// \/ Test Stuff (WIP)			
/*
			//int sys0 = requestdata(0x71);		//EMMState0
			//int sys1 = requestdata(0x72);		//EMMState1	
			//int en0  = requestdata(0x73);		//EMMIntState0
			//int en1  = requestdata(0x74);		//EMMIntState1

			//if true the MCU may not be getting data from the energy meter
			//if (sys0 == 65535 || sys0 == 0)	{printf("no data error");}

			// VOLTAGE
			//voltage = requestdata(0xD9) / 100;	//Line Voltage A, UrmsA

			// CURRENT
			//currentA = requestdata(0xDD) / 1000;	//Line Current A, IrmsA
			//currentB = requestdata(0xDE) / 1000;	//Line Current B, IrmsB
			//currentC = requestdata(0xDF) / 1000;	//Line Current C, IrmsC
			
			// Power
			//wattsA = requestdata32b(0xB1,0xC1) * 0.00032;		//Active Power A, High: B1, Low: C1
			//wattsB = requestdata32b(0xB2,0xC2) * 0.00032;		//Active Power B, High: B2, Low: C2
			//wattsC = requestdata32b(0xB3,0xC3) * 0.00032;		//Active Power C, High: B3, Low: C3

			//negativecheck(&currentA, &currentB, &currentC, &wattsA, &wattsB, &wattsC);
			//totalCurrent = currentA + currentB + currentC;
			//totalWatts = requestdata32b(0xB0,0xC0) * 0.00032;	//Total Active Power, High: B0, Low: C0		//all math is already done in the total register
			//totalWatts = wattsA + wattsB + wattsC;
			
			//powerfactorA = requestdata(0xBD) / 1000;	//Power Factor A, PFmeanA
			//powerfactorB = requestdata(0xBE) / 1000;	//Power Factor B, PFmeanB
			//powerfactorC = requestdata(0xBF) / 1000;	//Power Factor C, PFmeanC
			//powerfactortot = requestdata(0xBC) / 1000;	//Power Factor Total, PFmeanT

			// OTHER
			//temp = requestdata(0xFC);
			//freq = requestdata(0xF8);
			
			//int PLH = requestdata(0x31);			//(0x31, 0x0861); 2145		31  PL Constant MSB (default) - Meter Constant = 3200 - PL Constant = 140625000
			//int PLL = requestdata(0x0C);			//(0x32, 0xC468); 50280
			//printf("PL Constant (high): %i \n\r", PLH);
			//printf("PL Constant (low):  %i \n\r", PLL);
			
*/ 
// /\ Test Stuff (WIP)

			usart_putstr("AT+CIPSTART=0,\"TCP\",\"192.168.137.248\",\"1880\",5\r\n");	//get ready to send packet to NodeRED (5s timeout for response)
			_delay_ms(5000);
			usart_response(1);	//expects CONNECT
			
			//gigantic string containing the serialized json
			snprintf(string2, 400,"{\"voltage\": %.2f, \"currentA\": %.2f, \"currentB\": %.2f, \"currentC\": %.2f, \"freq\": %.2f, \"totalCurrent\": %.2f, \"totalWatts\": %.2f, \"wattsA\": %.2f, \"wattsB\": %.2f, \"wattsC\": %.2f, \"powerfactortot\": %.2f, \"temp\": %.2f}\r\n", voltage, currentA, currentB, currentC, freq, totalCurrent, totalWatts, wattsA, wattsB, wattsC, powerfactortot, temp);
			length = strlen(string2);
			sprintf(string1,"AT+CIPSEND=0,%i\r\n", length);
					
			//string sends
			printf("Sending\r\n");
			usart_putstr(string1);
			usart_response(0);
					
			usart_putstr(string2);
			_delay_ms(2500);
			usart_response(1);
					
			printf("Sent\r\n");
					
			//when response, close connection
			usart_putstr("AT+CIPCLOSE=0\r\n");
			usart_response(0);
			
			//time between loops
			_delay_ms(15000);
		}
	}
}
ISR(INT0_vect)
{

	_delay_us(MICROSECONDS_PER_BIT*1.5);				// time delay from start bit falling edge to center of D0

	
	uint8_t  bit_mask;
	uint8_t  temp;
	
	temp=0;
	for (bit_mask=0x01; bit_mask; bit_mask<<=1) {		// if bit a 1, write into correct bit (not nessisary for zeros)
		if((SOFT_RX_PORT&(1<<SOFT_RX_BIT))) {
			temp |= bit_mask;
		}
		_delay_us(MICROSECONDS_PER_BIT);				// wait for time of one bit (center of next data bit)
	}
	
	//	_delay_us(MICROSECONDS_PER_BIT*2);					// was for stop bits, but found to be unnessisary


	x[c]=temp;
	c++;
	EIFR=0x01;											// clear int flag (since any falling edge of the pin will
	// cause the interrupt flag to be set)
}
void usart_response (bool print)
{
	_delay_ms(1000);
	x[c]='\0';
	
	if (print == 1) {printf("%s**\t%i\n\r",x,c);}	//print if 1, else, don't print.
	c=0;
}
void serial_configure() {

	SOFT_TX_PORT |= (1<<SOFT_TX_BIT);
	SOFT_TX_DDR |= (1<<SOFT_TX_BIT);
	//	fdev_setup_stream (&usartout, usart_putchar, NULL, _FDEV_SETUP_WRITE);
	//	stdout = &usartout;

	SOFT_RX_DDR &= ~(1<<SOFT_RX_BIT);
	//	was not used: SOFT_RX_PORT &= ~(1<<SOFT_RX_BIT);

	EIMSK = 1<<INT0;
	EICRA = (1<<ISC01)|(0<<ISC00);
	
	sei();

}
int usart_putchar (char c) {

	cli();										//prevent interrupt for incoming characters
	uint8_t  bit_mask;

	// start bit
	SOFT_TX_PORT &= ~(1<<SOFT_TX_BIT);
	_delay_us(MICROSECONDS_PER_BIT);

	// data bits
	for (bit_mask=0x01; bit_mask; bit_mask<<=1) {
		if (c & bit_mask) {
			SOFT_TX_PORT |= (1<<SOFT_TX_BIT);
		}
		else {
			SOFT_TX_PORT &= ~(1<<SOFT_TX_BIT);
		}
		_delay_us(MICROSECONDS_PER_BIT);
	}

	// stop bit(s)
	SOFT_TX_PORT |= (1<<SOFT_TX_BIT);
	_delay_us(MICROSECONDS_PER_BIT);

	EIFR=0x01;															//clear int flag
	
	sei();																//turn back on interrupt
	return c;

}
void usart_putstr(char send_buff[255])
{
	for (int x=0;x<strlen(send_buff);x++)
	{
		usart_putchar(send_buff[x]);
		_delay_us(100);
	}
}
void setup_ATs()		//initializes ESP
{
	usart_putstr("AT+RST\r\n");
	usart_response(0);	//no print
	
	usart_putstr("AT+CWMODE=1\r\n");	//station mode, connects to nearby wifi
	_delay_ms(10);
	
	usart_putstr("AT+CWJAP=\"KretPC\",\"7Yp568n0\"\r\n");	//connect to your network
	_delay_ms(100);
	usart_response(1);	//print (expects ok if connection successful)
	
	usart_putstr("AT+CIFSR\r\n");		//retrieve assigned IP
	_delay_ms(100);
	printf("This ESP's IP is:\r\n");
	_delay_ms(100);
	usart_response(1);	//print assigned IP
}
void senddata(uint8_t address, uint16_t data)
{
	PORTB &= ~(_BV(PORTB2));  // Set CS Low

	// Send Address with MS Byte set to 0 (write mode)
	SPDR = 0x00;						// Send 0 for write
	while (!(SPSR & _BV(SPIF)));
	SPDR = address;						// Send lower byte of address
	while (!(SPSR & _BV(SPIF)));
	_delay_us(4);

	// Send 16-bit data (MSB first) 
	SPDR = (data >> 8);					// Send upper byte of data
	while (!(SPSR & _BV(SPIF)));
	SPDR = (data & 0xFF);					// Send lower byte of data
	while (!(SPSR & _BV(SPIF)));

	PORTB |= _BV(PORTB2);     // Set CS High
}
uint16_t requestdata(uint8_t address)
{
	uint16_t value = 0;
	PORTB &= ~(_BV(PORTB2));  // Set CS Low

	// Send Address with MS Byte set to 1 (read mode)
	SPDR = 0x80;						// Send 1 for read
	while (!(SPSR & _BV(SPIF)));
	SPDR = address;						// Send lower byte of address (the location)
	while (!(SPSR & _BV(SPIF)));
	_delay_us(4);
		
	// Receive 16-bit response (MSB first)
	SPDR = 0xFF;						// Send dummy byte to get MSB
	while (!(SPSR & _BV(SPIF)));
	value = SPDR << 8;					// Store MSB
	SPDR = 0xFF;						// Send dummy byte to get LSB
	while (!(SPSR & _BV(SPIF)));
	value |= SPDR;						// Store LSB

	PORTB |= _BV(PORTB2);	// Set CS High
	return value;
}
int requestdata32b(uint8_t highaddress, uint8_t lowaddress) 
{
	uint16_t val_h, val_l;
	val_h = requestdata(highaddress);
	val_l = requestdata(lowaddress);

	int val = ((uint32_t)val_h << 16) | (uint32_t)val_l;	//concatenate the 2 registers to make 1 32 bit number
	return (val);
}
void atm90e32initialization()
{
	/* ATM90E32AS SETUP	  (Register #  Name) */
	senddata(0x70, 0x789A);		// 70  SoftReset
	senddata(0x7F, 0x55AA);		// 7F  CfgRegAccEn
	senddata(0x00, 0x0001);		// 00  Enable Metering
		
	senddata(0x05, 0x143F);		// 05  Sag and Voltage peak detect period set to 20ms
/**/senddata(0x08, 0xCFCE);     // 08  Voltage sag threshold		/Found using vSagTh = (sagV * 100 * sqrt(2)) / (2 * _ugain / 32768) ((sagV = 90 chosen for 120v US & _ugain = 3920 for chosen power supply))
/**/senddata(0x0D, 0x17D4);		// 0D  High frequency threshold		/Found using FreqHiThresh = 61 * 100
/**/senddata(0x0C, 0x170C);		// 0C  Lo frequency threshold		/Found using FreqLoThresh = 59 * 100
	senddata(0x75, 0xB76F);     // 75  Enable interrupts
	senddata(0x76, 0xDDFD);     // 76  Enable interrupts
	senddata(0x73, 0x0001);		// 73  Clear interrupt flags
	senddata(0x74, 0x0001);		// 74  Clear interrupt flags
	senddata(0x07, 0xD654);     // 07  ZX2, ZX1, ZX0 pin config - set to current channels, all polarity

	//Set metering config values (CONFIG)
	senddata(0x31, 0x0861);		// 31  PL Constant MSB (default) - Meter Constant = 3200 - PL Constant = 140625000
	senddata(0x32, 0xC468);		// 32  PL Constant LSB (default) - this is 4C68 in the application note, which is incorrect
/**/senddata(0x33, 0x5487);		// 33  Mode Config (frequency set in main program)
/**/senddata(0x34, 0x0000);		// 34  PGA Gain Configuration for Current Channels - 0x002A (x4) // 0x0015 (x2) // 0x0000 (1x)
	senddata(0x35, 0x1D4C);		// 35  All phase Active Startup Power Threshold - 50% of startup current = 0.02A/0.00032 = 7500
	senddata(0x36, 0x1D4C);		// 36  All phase Reactive Startup Power Threshold
	senddata(0x37, 0x1D4C);		// 37  All phase Apparent Startup Power Threshold
	senddata(0x38, 0x02EE);		// 38  Each phase Active Phase Threshold = 10% of startup current = 0.002A/0.00032 = 750
	senddata(0x39, 0x02EE);		// 39  Each phase Reactive Phase Threshold
	senddata(0x3A, 0x02EE);		// 3A  Each phase Apparent Phase Threshold

	//Set metering calibration values (CALIBRATION)
	senddata(0x47, 0x0000);		// 47  Line calibration gain
	senddata(0x48, 0x0000);		// 48  Line calibration angle
	senddata(0x49, 0x0000);		// 49  Line calibration gain
	senddata(0x4A, 0x0000);		// 4A  Line calibration angle
	senddata(0x4B, 0x0000);		// 4B  Line calibration gain
	senddata(0x4C, 0x0000);		// 4C  Line calibration angle
	senddata(0x41, 0x0000);		// 41  A line active power offset FFDC
	senddata(0x42, 0x0000);		// 42  A line reactive power offset
	senddata(0x43, 0x0000);		// 43  B line active power offset
	senddata(0x44, 0x0000);		// 44  B line reactive power offset
	senddata(0x45, 0x0000);		// 45  C line active power offset
	senddata(0x46, 0x0000);		// 46  C line reactive power offset

	//Set metering calibration values (HARMONIC)
	senddata(0x51, 0x0000);		// 51  A Fund. active power offset
	senddata(0x52, 0x0000);		// 52  B Fund. active power offset
	senddata(0x53, 0x0000);		// 53  C Fund. active power offset
	senddata(0x54, 0x0000);     // 54  A Fund. active power gain
	senddata(0x55, 0x0000);     // 55  B Fund. active power gain
	senddata(0x56, 0x0000);     // 56  C Fund. active power gain

	//Set measurement calibration values (ADJUST)
/**/senddata(0x61, 0x0F50);		// 61  A Voltage rms gain		/Found with _ugain (3920 for our power supply)
/**/senddata(0x62, 0x27BA);		// 62  A line current gain		/10170 for 20A:25ma CT, Found in energy_meter.h @ https://github.com/CircuitSetup/Split-Single-Phase-Energy-Meter/blob/master/Software/EmonESP/src/energy_meter.h
	senddata(0x63, 0x0000);		// 63  A Voltage offset - 61A8
	senddata(0x64, 0x0000);		// 64  A line current offset - FE60
/**/senddata(0x65, 0x0F50);     // 65  B Voltage rms gain		/Found with _ugain (3920 for our power supply)
/**/senddata(0x66, 0x639A);		// 66  B line current gain		/25498 for 100A:50ma CT, Found in energy_meter.h @ https://github.com/CircuitSetup/Split-Single-Phase-Energy-Meter/blob/master/Software/EmonESP/src/energy_meter.h
	senddata(0x67, 0x0000);		// 67  B Voltage offset - 1D4C
	senddata(0x68, 0x0000);		// 68  B line current offset - FE60
/**/senddata(0x69, 0x0F50);     // 69  C Voltage rms gain		/Found with _ugain (3920 for our power supply)
/**/senddata(0x6A, 0xD6FC);		// 6A  C line current gain		/Manually Calculated for 200A:50ma CT, Found in energy_meter.h @ https://github.com/CircuitSetup/Split-Single-Phase-Energy-Meter/blob/master/Software/EmonESP/src/energy_meter.h
	senddata(0x6B, 0x0000);		// 6B  C Voltage offset - 1D4C
	senddata(0x6C, 0x0000);		// 6C  C line current offset

	senddata(0x7F, 0x0000);		// 7F end configuration
}
void negativecheck(float *currentA, float *currentB, float *currentC, int *wattsA, int *wattsB, int *wattsC)
{	
	if (*currentA < 0) {*currentA *= -1;}		//if currentA-C or wattsA-C are negative, flip
	if (*currentB < 0) {*currentB *= -1;}
	if (*currentC < 0) {*currentC *= -1;}
		
	if (*wattsA < 0) {*wattsA *= -1;}
	if (*wattsB < 0) {*wattsB *= -1;}
	if (*wattsC < 0) {*wattsC *= -1;}	
}